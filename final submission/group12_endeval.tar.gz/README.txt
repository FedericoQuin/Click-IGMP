
==============================================
| Project Telecommunicaton 3rd year bachelor |
==============================================

Down below, we will list all the handlers that can be called on certain elements within the client/router.


Handlers in client:
 * reportSource.join_group IPAddress
 * reportSource.join_group IPAddress
 * clientState.setUnsolicitedReportInterval int

Handlers in router:
 * routerState.set_qrv uint8_t
 * routerState.set_qi int
 * routerState.set_qri int
 * routerState.set_lmqi int
 * routerState.set_lmqc int



Made by Cédric De Haes & Federico Quin